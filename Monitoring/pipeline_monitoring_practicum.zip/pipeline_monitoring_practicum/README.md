# Pipeline Monitoring & Alerting Practicum

Lihat dokumentasi lengkap pada `PANDUAN_PRAKTIKUM_PIPELINE_MONITORING_ALERTING.md`.

## Quick start
1. Salin `.env.example` menjadi `.env`.
2. Jalankan `docker compose build`.
3. Jalankan `docker compose up airflow-init`.
4. Jalankan `docker compose up -d`.
5. Buka http://localhost:8080 (airflow / airflow).
6. Jalankan DAG `etl_monitoring_demo`.

Hentikan: `docker compose down`
Hapus seluruh database latihan: `docker compose down --volumes`
